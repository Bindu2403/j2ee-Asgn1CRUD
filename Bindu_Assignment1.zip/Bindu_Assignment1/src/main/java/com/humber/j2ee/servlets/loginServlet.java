package com.humber.j2ee.servlets;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Connection;


@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public loginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = "";
        String type = "";
        String flag = "false";
        HttpSession session = request.getSession();

        // Database connection details
        String url = "jdbc:mysql://localhost:3306/RestaurantDB";
        String dbUsername = "root";
        String dbPassword = "Binchow1428";

        try {
            // Register the MySQL driver class
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create a connection to the database
            Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);

            String sql = "SELECT * FROM users WHERE email=? AND password=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                name = result.getString("name");
                System.out.println(result.getString("type"));
                type = result.getString("type");

                session.setAttribute("username", name);
                session.setAttribute("type", type);

                response.sendRedirect("home.jsp");
                System.out.println(result.getString("email"));
                System.out.println(result.getString("password"));
            } else {
                session.setAttribute("flag", flag);
                System.out.print("Invalid username or password.");
                response.sendRedirect("index.jsp");
            }
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
