package com.humber.j2ee.servlets;



import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@MultipartConfig
@WebServlet("/Insert_Data")
public class insert_Data extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insert_Data() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jdbcURL = "jdbc:mysql://localhost:3306/RestaurantDB";
        String username = "root";
        String password = "Binchow1428";
        
        try {
           
            String name = request.getParameter("name");
            name = name.trim();
            String description = request.getParameter("description");
            
            String flavor = request.getParameter("choice");
            
            String ingrediants = request.getParameter("ingrediants");
            String price = request.getParameter("price");
            
            Part filePart = request.getPart("image");
            InputStream inputStream = filePart.getInputStream();
            System.out.println(description);

            	Class.forName("com.mysql.jdbc.Driver");
            	Connection connection = DriverManager.getConnection(jdbcURL, username, password);
            	System.out.println("Connection Sucessful!");
                
            	String sql = "INSERT INTO menu_itmes (item_name, short_desc, flavor, ingrediants, price, image_data) VALUES (?, ?, ?, ?, ?, ?)";
            	PreparedStatement statement = connection.prepareStatement(sql);
            	statement.setString(1, name);
            	statement.setString(2, description);
            	statement.setString(3, flavor);
            	statement.setString(4, ingrediants);
            	statement.setString(5, price);
            	statement.setBlob(6, inputStream);
                statement.executeUpdate();
                System.out.println("Inserted Sucessfully");	
                
                connection.close();

                response.sendRedirect("home.jsp");	
              }
             catch (Exception e) {
            
            e.printStackTrace();
            
        }
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
